import React from 'react'
import QuestMapper from './QuestMapper'

export default function App() {
  return <QuestMapper />
}
